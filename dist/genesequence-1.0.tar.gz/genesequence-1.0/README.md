# Genesequence_package
AWS Scholarship Capstone Project - A light-weight bioinformatics package
